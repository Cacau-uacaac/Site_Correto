
let slides = document.querySelectorAll('.slide-container')
let teste = 0;

function next(){

    slides[teste].classList.remove('active');
    teste = (teste - 1 + slides.length) % slides.length;
    slides[teste].classList.add('active');
}

function prev(){
    slides[teste].classList.remove('active');
    teste = (teste - 1 + slides.length) % slides.length;
    slides[teste].classList.add('active');
}

setInterval(next, 6000);