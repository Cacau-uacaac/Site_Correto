<?php
include ("conexao.php");


    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $genero = ""; // Initialize the $genero variable as an empty string

    $logi=$_POST['login'];
    $pass=$_POST['pass'];


    if (isset($_POST['genero'])) {
        $genero = $_POST['genero'];
    }

$sql = "INSERT INTO informacoes (nome, sobrenome, email, senha, genero) 
VALUES ('$nome', '$sobrenome', '$email', '$senha', '$genero')";

    $sql2 = "INSERT INTO cad (logi, pass) VALUES ('$logi', '$pass')";

    $result = mysqli_query($conn, $sql);

    if($result){
        header("Location: index.html");
    }
    else{
        echo "Falhou :".mysqli_error($conexao);
    }



?>