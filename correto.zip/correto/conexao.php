<?php 
$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "cadastro";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if(!$conn){
    die("Houve um  Erro". mysqli_connect_error());
}
//echo "Conexão Bem sucedida";