<?php
include ("conexao.php");

    $logi=$_POST['login'];
    $pass=$_POST['pass'];

    $sql2 = "INSERT INTO cad (logi, pass) VALUES ('$logi', '$pass')";

    $result = mysqli_query($conn, $sql2);

    if($result){
        header("Location: homeP.html");
    }
    else{
        echo "Falhou :".mysqli_error($conexao);
    }

?>